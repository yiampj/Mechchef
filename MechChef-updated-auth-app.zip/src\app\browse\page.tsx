import { SlidersHorizontal } from "lucide-react";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { MealCard } from "@/components/MealCard";
import { cuisines, meals } from "@/lib/demo-data";

export default function BrowsePage() {
  return (
    <main>
      <Header />
      <section className="bg-white px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-mech-red">Search and filters</p>
              <h1 className="font-heading text-5xl font-black">Browse meals</h1>
              <p className="mt-3 max-w-2xl text-mech-muted">
                Filter by dish, location, cuisine, dietary preference, meal type, price, rating, and delivery timing.
              </p>
            </div>
            <button className="inline-flex items-center justify-center gap-2 rounded-lg border border-mech-line px-4 py-3 text-sm font-black">
              <SlidersHorizontal size={18} />
              More filters
            </button>
          </div>

          <div className="mb-8 grid gap-3 rounded-xl border border-mech-line bg-mech-cream p-3 md:grid-cols-5">
            <input className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none md:col-span-2" placeholder="Dish, ingredient, cook" />
            <input className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none" placeholder="Postcode or city" />
            <select className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none">
              {cuisines.map((cuisine) => <option key={cuisine}>{cuisine}</option>)}
            </select>
            <select className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none">
              <option>Any dietary</option>
              <option>Vegan</option>
              <option>Vegetarian</option>
              <option>Gluten Free</option>
              <option>Halal</option>
            </select>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {meals.map((meal) => (
              <MealCard key={meal.id} meal={meal} />
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
