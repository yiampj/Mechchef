import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const mealSchema = z.object({
  cookId: z.string().min(1),
  name: z.string().min(2),
  description: z.string().min(10),
  price: z.number().positive(),
  category: z.string().min(2),
  cuisine: z.string().min(2),
  dietaryTags: z.array(z.string()).default([]),
  imageUrl: z.string().url().optional(),
  portionSize: z.string().default("1 portion"),
  deliveryTime: z.string().default("45-60 min"),
  stock: z.number().int().nonnegative().default(10)
});

export async function GET() {
  const meals = await prisma.meal.findMany({
    where: { isAvailable: true },
    include: {
      cook: {
        include: {
          user: {
            select: { name: true, address: true }
          }
        }
      }
    },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ meals });
}

export async function POST(request: Request) {
  const parsed = mealSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid meal payload" }, { status: 400 });
  }

  const meal = await prisma.meal.create({
    data: parsed.data
  });

  return NextResponse.json({ meal }, { status: 201 });
}
