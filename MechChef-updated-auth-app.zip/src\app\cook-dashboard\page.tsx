import { BadgeCheck, Banknote, Bell, ChartNoAxesCombined, ClipboardList, ImagePlus, Utensils } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";

const cards: { title: string; text: string; icon: LucideIcon }[] = [
  { title: "Menu Management", text: "Create meals, upload images, set stock, portion size, and delivery slots.", icon: Utensils },
  { title: "Orders Management", text: "Confirm orders, update preparation status, and coordinate delivery.", icon: ClipboardList },
  { title: "Earnings and Payouts", text: "Track revenue, commission, featured listings, and payout status.", icon: Banknote },
  { title: "Performance Analytics", text: "Measure ratings, repeat customers, bestsellers, and fulfilment time.", icon: ChartNoAxesCombined },
  { title: "Cook Verification", text: "Manage food hygiene, ID checks, kitchen approval, and compliance.", icon: BadgeCheck },
  { title: "Notifications", text: "Receive order, payout, review, and platform updates.", icon: Bell }
];

export default function CookDashboardPage() {
  return (
    <main>
      <Header />
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-mech-red">For cooks</p>
              <h1 className="font-heading text-5xl font-black">Cook dashboard</h1>
              <p className="mt-3 max-w-2xl leading-7 text-mech-muted">
                The operational home for verified cooks: menu content, quality, orders, earnings, analytics, and alerts.
              </p>
            </div>
            <button className="inline-flex items-center justify-center gap-2 rounded-lg bg-mech-red px-5 py-3 text-sm font-black text-white">
              <ImagePlus size={18} />
              Add meal
            </button>
          </div>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {cards.map(({ title, text, icon: Icon }) => (
              <article key={title} className="rounded-lg border border-mech-line bg-white p-6">
                <Icon className="mb-5 text-mech-red" size={28} />
                <h2 className="font-heading text-2xl font-bold">{title}</h2>
                <p className="mt-3 text-sm leading-7 text-mech-muted">{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
