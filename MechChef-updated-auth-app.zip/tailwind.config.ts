import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        mech: {
          dark: "#1a1a18",
          red: "#C8472B",
          gold: "#D4A843",
          cream: "#faf9f7",
          ink: "#2e2e2b",
          muted: "#706f68",
          line: "#e6e1d8"
        }
      },
      fontFamily: {
        heading: ["var(--font-playfair)", "Georgia", "serif"],
        sans: ["var(--font-dm-sans)", "system-ui", "sans-serif"]
      },
      boxShadow: {
        soft: "0 20px 50px rgba(26, 26, 24, 0.10)"
      }
    }
  },
  plugins: []
};

export default config;
