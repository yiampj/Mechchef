export { default } from "../../cook-dashboard/page";
