import { NextResponse } from "next/server";
import { z } from "zod";
import { stripe } from "@/lib/stripe";

const checkoutSchema = z.object({
  items: z
    .array(
      z.object({
        name: z.string().min(1),
        price: z.number().positive(),
        quantity: z.number().int().positive(),
        imageUrl: z.string().url().optional()
      })
    )
    .min(1),
  deliveryAddress: z.string().min(5),
  deliverySlot: z.string().min(3)
});

export async function POST(request: Request) {
  const parsed = checkoutSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid checkout payload" }, { status: 400 });
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    success_url: `${appUrl}/orders?status=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${appUrl}/checkout?status=cancelled`,
    shipping_address_collection: {
      allowed_countries: ["GB"]
    },
    metadata: {
      deliveryAddress: parsed.data.deliveryAddress,
      deliverySlot: parsed.data.deliverySlot
    },
    line_items: parsed.data.items.map((item) => ({
      quantity: item.quantity,
      price_data: {
        currency: "gbp",
        unit_amount: Math.round(item.price * 100),
        product_data: {
          name: item.name,
          images: item.imageUrl ? [item.imageUrl] : undefined
        }
      }
    }))
  });

  return NextResponse.json({ url: session.url });
}
