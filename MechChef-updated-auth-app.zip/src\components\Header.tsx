import Link from "next/link";
import { ChefHat, MapPin, ShoppingBag } from "lucide-react";
import { AuthNav } from "@/components/AuthNav";

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-mech-line bg-white/95 backdrop-blur">
      <div className="bg-mech-dark px-4 py-2 text-center text-xs font-semibold tracking-wide text-mech-cream">
        Launching in Harrow and Newham. Verified home cooks, fresh daily menus.
      </div>
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-mech-dark text-mech-gold">
            <ChefHat size={21} />
          </span>
          <span className="font-heading text-2xl font-black">
            Mech<span className="text-mech-red">Chef</span>
          </span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          <Link className="rounded-md px-3 py-2 text-sm font-semibold text-mech-muted hover:bg-mech-cream hover:text-mech-dark" href="/browse">
            Browse Meals
          </Link>
          <Link className="rounded-md px-3 py-2 text-sm font-semibold text-mech-muted hover:bg-mech-cream hover:text-mech-dark" href="/cooks">
            Find Cooks
          </Link>
          <Link className="rounded-md px-3 py-2 text-sm font-semibold text-mech-muted hover:bg-mech-cream hover:text-mech-dark" href="/orders">
            Track Order
          </Link>
          <Link className="rounded-md px-3 py-2 text-sm font-semibold text-mech-muted hover:bg-mech-cream hover:text-mech-dark" href="/cook/dashboard">
            Cook Dashboard
          </Link>
          <Link className="rounded-md px-3 py-2 text-sm font-semibold text-mech-muted hover:bg-mech-cream hover:text-mech-dark" href="/admin">
            Admin
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <button className="hidden items-center gap-2 rounded-md border border-mech-line bg-white px-3 py-2 text-sm font-semibold text-mech-muted sm:flex">
            <MapPin size={16} />
            London
          </button>
          <AuthNav />
          <Link aria-label="Basket" className="grid h-10 w-10 place-items-center rounded-md bg-mech-dark text-white" href="/checkout">
            <ShoppingBag size={18} />
          </Link>
        </div>
      </nav>
    </header>
  );
}
