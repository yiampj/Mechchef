"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn, getSession } from "next-auth/react";
import { ChefHat } from "lucide-react";
import { FormEvent, useState } from "react";
import { getRoleRedirect } from "@/lib/role-redirect";

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setIsLoading(true);

    const formData = new FormData(event.currentTarget);
    const email = String(formData.get("email") ?? "");
    const password = String(formData.get("password") ?? "");

    const result = await signIn("credentials", {
      email,
      password,
      redirect: false
    });

    if (result?.error) {
      setError("Email or password is incorrect");
      setIsLoading(false);
      return;
    }

    const session = await getSession();
    router.push(getRoleRedirect(session?.user.role));
    router.refresh();
  }

  return (
    <main className="grid min-h-screen place-items-center bg-mech-cream px-4 py-10">
      <section className="w-full max-w-md rounded-xl border border-mech-line bg-white p-8 shadow-soft">
        <Link href="/" className="mb-8 flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-mech-dark text-mech-gold">
            <ChefHat size={21} />
          </span>
          <span className="font-heading text-2xl font-black">
            Mech<span className="text-mech-red">Chef</span>
          </span>
        </Link>
        <p className="text-xs font-black uppercase tracking-widest text-mech-red">Welcome back</p>
        <h1 className="mt-2 font-heading text-4xl font-black">Login</h1>
        <form className="mt-7 grid gap-4" onSubmit={handleSubmit}>
          <label className="grid gap-2 text-sm font-bold">
            Email
            <input
              className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red"
              name="email"
              placeholder="you@example.com"
              required
              type="email"
            />
          </label>
          <label className="grid gap-2 text-sm font-bold">
            Password
            <input
              className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red"
              name="password"
              placeholder="Minimum 6 characters"
              required
              type="password"
            />
          </label>
          {error ? <p className="rounded-md bg-red-50 px-3 py-2 text-sm font-bold text-mech-red">{error}</p> : null}
          <button
            className="mt-2 rounded-lg bg-mech-red px-5 py-3 text-sm font-black text-white hover:bg-mech-dark disabled:cursor-not-allowed disabled:opacity-70"
            disabled={isLoading}
            type="submit"
          >
            {isLoading ? "Logging in..." : "Login"}
          </button>
        </form>
        <p className="mt-5 text-sm leading-6 text-mech-muted">
          New to MechChef?{" "}
          <Link className="font-black text-mech-red" href="/signup">
            Create an account
          </Link>
        </p>
      </section>
    </main>
  );
}
