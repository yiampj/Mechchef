"use client";

import Link from "next/link";
import { signOut, useSession } from "next-auth/react";
import { LogOut, UserRound } from "lucide-react";

export function AuthNav() {
  const { data: session, status } = useSession();

  if (status === "loading") {
    return (
      <span className="hidden h-10 w-24 rounded-md border border-mech-line bg-mech-cream sm:block" />
    );
  }

  if (!session?.user) {
    return (
      <div className="flex items-center gap-2">
        <Link
          className="hidden rounded-md border border-mech-line px-3 py-2 text-sm font-black text-mech-dark hover:border-mech-dark sm:inline-flex"
          href="/login"
        >
          Login
        </Link>
        <Link
          aria-label="Create account"
          className="grid h-10 w-10 place-items-center rounded-md border border-mech-line text-mech-dark sm:hidden"
          href="/login"
        >
          <UserRound size={18} />
        </Link>
        <Link
          className="hidden rounded-md bg-mech-red px-3 py-2 text-sm font-black text-white hover:bg-mech-dark sm:inline-flex"
          href="/signup"
        >
          Sign up
        </Link>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <span className="hidden max-w-36 truncate rounded-md border border-mech-line px-3 py-2 text-sm font-black text-mech-dark sm:inline">
        {session.user.name ?? session.user.email}
      </span>
      <button
        aria-label="Logout"
        className="grid h-10 w-10 place-items-center rounded-md border border-mech-line text-mech-dark hover:border-mech-dark"
        onClick={() => signOut({ callbackUrl: "/" })}
        type="button"
      >
        <LogOut size={18} />
      </button>
    </div>
  );
}
