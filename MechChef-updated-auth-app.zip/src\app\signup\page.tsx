"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn, getSession } from "next-auth/react";
import { ChefHat } from "lucide-react";
import { FormEvent, useState } from "react";
import { getRoleRedirect } from "@/lib/role-redirect";

type SignupRole = "CUSTOMER" | "COOK";

export default function SignupPage() {
  const router = useRouter();
  const [role, setRole] = useState<SignupRole>("CUSTOMER");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setIsLoading(true);

    const formData = new FormData(event.currentTarget);
    const payload = {
      name: String(formData.get("name") ?? ""),
      email: String(formData.get("email") ?? ""),
      password: String(formData.get("password") ?? ""),
      role
    };

    const response = await fetch("/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const data = (await response.json()) as { error?: string };
      setError(data.error ?? "Could not create your account");
      setIsLoading(false);
      return;
    }

    const result = await signIn("credentials", {
      email: payload.email,
      password: payload.password,
      redirect: false
    });

    if (result?.error) {
      router.push("/login");
      return;
    }

    const session = await getSession();
    router.push(getRoleRedirect(session?.user.role));
    router.refresh();
  }

  return (
    <main className="grid min-h-screen place-items-center bg-mech-cream px-4 py-10">
      <section className="w-full max-w-lg rounded-xl border border-mech-line bg-white p-8 shadow-soft">
        <Link href="/" className="mb-8 flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-mech-dark text-mech-gold">
            <ChefHat size={21} />
          </span>
          <span className="font-heading text-2xl font-black">
            Mech<span className="text-mech-red">Chef</span>
          </span>
        </Link>
        <p className="text-xs font-black uppercase tracking-widest text-mech-red">Join MechChef</p>
        <h1 className="mt-2 font-heading text-4xl font-black">Sign up</h1>
        <form className="mt-7 grid gap-4" onSubmit={handleSubmit}>
          <label className="grid gap-2 text-sm font-bold">
            Name
            <input
              className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red"
              name="name"
              placeholder="Your full name"
              required
              type="text"
            />
          </label>
          <label className="grid gap-2 text-sm font-bold">
            Email
            <input
              className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red"
              name="email"
              placeholder="you@example.com"
              required
              type="email"
            />
          </label>
          <label className="grid gap-2 text-sm font-bold">
            Password
            <input
              className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red"
              name="password"
              placeholder="Minimum 6 characters"
              required
              type="password"
            />
          </label>
          <div className="grid gap-2 text-sm font-bold">
            Role
            <div className="grid grid-cols-2 gap-2 rounded-lg bg-mech-cream p-1">
              {(["CUSTOMER", "COOK"] as const).map((option) => (
                <button
                  className={`rounded-md px-4 py-3 text-sm font-black ${
                    role === option
                      ? "bg-mech-dark text-white"
                      : "bg-transparent text-mech-muted hover:bg-white"
                  }`}
                  key={option}
                  onClick={() => setRole(option)}
                  type="button"
                >
                  {option === "CUSTOMER" ? "Customer" : "Cook"}
                </button>
              ))}
            </div>
          </div>
          {error ? <p className="rounded-md bg-red-50 px-3 py-2 text-sm font-bold text-mech-red">{error}</p> : null}
          <button
            className="mt-2 rounded-lg bg-mech-red px-5 py-3 text-sm font-black text-white hover:bg-mech-dark disabled:cursor-not-allowed disabled:opacity-70"
            disabled={isLoading}
            type="submit"
          >
            {isLoading ? "Creating account..." : "Create account"}
          </button>
        </form>
        <p className="mt-5 text-sm leading-6 text-mech-muted">
          Already have an account?{" "}
          <Link className="font-black text-mech-red" href="/login">
            Login
          </Link>
        </p>
      </section>
    </main>
  );
}
