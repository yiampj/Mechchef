import type { Role } from "@prisma/client";

export function getRoleRedirect(role?: Role | null) {
  if (role === "COOK") return "/cook/dashboard";
  if (role === "ADMIN") return "/admin";
  return "/browse";
}
